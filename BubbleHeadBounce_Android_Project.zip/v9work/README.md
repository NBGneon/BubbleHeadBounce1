# Bubble Head Bounce

Complete offline Android 2D arcade game project.

## Image roles
1. `head.png` — main gameplay collision head
2. `win.png` — win screen
3. `lose.png` — bomb-hit screen
4. `retry.png` — better-luck/retry screen
5. `ui_ref1.png` — menu/UI decorative reference
6. `ui_ref2.png` — menu/UI decorative reference

The supplied black backgrounds are chroma-keyed to transparency for clean compositing; the artwork itself is preserved.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build APK(s)

Minimum Android: 6.0 (API 23)
Target SDK: 35
Portrait only.
No network permission and no external runtime dependencies.
