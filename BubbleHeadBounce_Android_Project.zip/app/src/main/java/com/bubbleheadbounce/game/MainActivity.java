package com.bubbleheadbounce.game;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

/** Main activity. Uses non-overlapping transparent touch views over the canvas buttons. */
public class MainActivity extends Activity {
    private GameView game;
    private FrameLayout root;
    private View play, howTo, back, again, menu;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.rgb(7,17,31));

        root = new FrameLayout(this);
        game = new GameView(this);
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));

        play = makeButton(v -> game.startGame());
        howTo = makeButton(v -> game.showHowTo());
        back = makeButton(v -> game.showMenu());
        again = makeButton(v -> game.startGame());
        menu = makeButton(v -> game.showMenu());

        root.addView(play);
        root.addView(howTo);
        root.addView(back);
        root.addView(again);
        root.addView(menu);

        setContentView(root);
        game.setStateListener(this::refreshButtons);
        root.post(this::refreshButtons);
    }

    private View makeButton(View.OnClickListener listener) {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setClickable(true);
        v.setFocusable(false);
        v.setOnClickListener(listener);
        return v;
    }

    /**
     * Places each touch target exactly over its matching canvas button.
     * There are NO overlapping touch targets.
     */
    private void place(View v, float left, float top, float width, float height, boolean visible, float scale) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Math.round(width * scale), Math.round(height * scale));
        lp.leftMargin = Math.round(left * scale);
        lp.topMargin = Math.round(top * scale);
        v.setLayoutParams(lp);
        v.setVisibility(visible ? View.VISIBLE : View.GONE);
        v.setClickable(visible);
    }

    private void refreshButtons() {
        if (root == null || game == null || game.getWidth() == 0 || game.getHeight() == 0) return;

        float scale = Math.min(game.getWidth() / 1080f, game.getHeight() / 1920f);
        if (scale <= 0) scale = 1f;

        GameView.Screen s = game.getScreen();

        // Canvas button positions: x=160..920, height=110.
        // Each target is separated from the next one.
        place(play, 160, 760, 760, 110, s == GameView.Screen.MENU, scale);
        place(howTo, 160, 895, 760, 110, s == GameView.Screen.MENU, scale);
        place(back, 160, 1120, 760, 110, s == GameView.Screen.HOWTO, scale);
        place(again, 160, 1370, 760, 110, s == GameView.Screen.GAMEOVER, scale);
        place(menu, 160, 1505, 760, 110, s == GameView.Screen.GAMEOVER, scale);
    }
}
