package com.bubbleheadbounce.game;

import android.content.Context;
import android.graphics.*;
import android.media.MediaPlayer;
import android.view.*;
import java.util.*;

public class GameView extends View {
    enum Screen { MENU, HOWTO, PLAY, PAUSE, GAMEOVER }
    private Screen screen = Screen.MENU;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private Bitmap head, lose, retry, ref1, ref2;
    private final ArrayList<Fall> falls = new ArrayList<>();
    private final ArrayList<Pop> pops = new ArrayList<>();
    private float playerX, targetX, shake;
    private long last, spawnClock;
    private int score, best;
    private float W, H, scale = 1f;
    private MediaPlayer popS, hitS;
    private final Handler handler = new Handler();
    private boolean loopRunning = false;

    class Fall {
        float x,y,r,vy,drift; boolean bomb;
        Fall(float x,float y,float r,float vy,boolean bomb){this.x=x;this.y=y;this.r=r;this.vy=vy;this.bomb=bomb;drift=(rng.nextFloat()*2-1)*.55f;}
    }
    class Pop { float x,y,life; String text; Pop(float x,float y,String t){this.x=x;this.y=y;text=t;life=1;} }

    public GameView(Context c) {
        super(c);
        setFocusable(true);
        setClickable(true);
        setFocusableInTouchMode(true);
        requestFocus();
        head=load(R.drawable.head); lose=load(R.drawable.lose); retry=load(R.drawable.retry);
        ref1=load(R.drawable.ui_ref1); ref2=load(R.drawable.ui_ref2);
        try { popS=MediaPlayer.create(c,R.raw.pop); hitS=MediaPlayer.create(c,R.raw.hit); } catch(Exception ignored) {}
        best=c.getSharedPreferences("save",0).getInt("best",0);
    }
    Bitmap load(int id){return BitmapFactory.decodeResource(getResources(),id);}
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        W=w; H=h; scale=Math.min(W/1080f,H/1920f); if(scale<=0)scale=1f;
        playerX=W/2f; targetX=playerX;
    }
    float s(float v){return v*scale;}
    float logicalX(float x){return x/scale;}
    float logicalY(float y){return y/scale;}

    void bg(Canvas c){
        c.drawColor(Color.rgb(7,17,31));
        p.setShader(new LinearGradient(0,0,0,H,Color.rgb(10,32,60),Color.rgb(35,8,58),Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p); p.setShader(null);
        p.setColor(0x1835D6FF);
        for(int i=0;i<12;i++) c.drawCircle((i*137)%W,(i*263+80)%H,s(4+(i%3)*3),p);
    }
    void text(Canvas c,String t,float x,float y,float size,int color,Paint.Align align){
        p.setTypeface(Typeface.create("sans",Typeface.BOLD)); p.setTextSize(s(size)); p.setColor(color); p.setTextAlign(align); p.setStyle(Paint.Style.FILL); c.drawText(t,x,y,p);
    }
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,s(rad),s(rad),p);}
    void button(Canvas c,String label,float y){float l=s(160),r=W-s(160),t=s(y),b=s(y+110);round(c,l,t,r,b,28,0xFF21B6E8);round(c,l+s(5),t+s(5),r-s(5),b-s(5),24,0xFF123C6B);text(c,label,W/2,t+s(72),38,Color.WHITE,Paint.Align.CENTER);}
    void drawBitmapContain(Canvas c,Bitmap b,float cx,float cy,float maxW,float maxH){if(b==null)return;float k=Math.min(s(maxW)/b.getWidth(),s(maxH)/b.getHeight());float bw=b.getWidth()*k,bh=b.getHeight()*k;c.drawBitmap(b,null,new RectF(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2),p);}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); bg(c);
        if(screen==Screen.MENU) menu(c); else if(screen==Screen.HOWTO) howto(c); else if(screen==Screen.PLAY||screen==Screen.PAUSE) play(c); else result(c);
    }

    void menu(Canvas c){
        text(c,"BUBBLE",W/2,s(165),78,Color.WHITE,Paint.Align.CENTER); text(c,"HEAD BOUNCE",W/2,s(245),62,0xFF5DE3FF,Paint.Align.CENTER);
        drawBitmapContain(c,ref1,s(165),s(470),240,330); drawBitmapContain(c,ref2,W-s(165),s(470),220,330); drawBitmapContain(c,head,W/2,s(490),350,350);
        button(c,"PLAY",760); button(c,"HOW TO PLAY",895); button(c,"BEST SCORE  "+best,1030);
        text(c,"Catch the bubbles • Dodge the bombs",W/2,s(1175),25,0xFFD9EEFF,Paint.Align.CENTER);
        text(c,"Offline arcade",W/2,s(1215),21,0xFF8FB0C9,Paint.Align.CENTER);
    }
    void howto(Canvas c){
        text(c,"HOW TO PLAY",W/2,s(160),58,Color.WHITE,Paint.Align.CENTER); round(c,s(80),s(245),W-s(80),s(1040),36,0xCC102744);
        text(c,"CATCH THE BALLS",W/2,s(345),34,0xFF62E8FF,Paint.Align.CENTER); text(c,"Move your head left & right",W/2,s(410),28,Color.WHITE,Paint.Align.CENTER); text(c,"to collect falling bubbles.",W/2,s(455),28,Color.WHITE,Paint.Align.CENTER);
        text(c,"AVOID THE BOMBS",W/2,s(555),34,0xFFFF7676,Paint.Align.CENTER); text(c,"A bomb touching your head",W/2,s(620),28,Color.WHITE,Paint.Align.CENTER); text(c,"ends the run immediately.",W/2,s(665),28,Color.WHITE,Paint.Align.CENTER);
        text(c,"UNLIMITED SCORE",W/2,s(765),34,0xFFFFD15C,Paint.Align.CENTER); text(c,"Keep collecting bubbles for as long as you can.",W/2,s(830),25,Color.WHITE,Paint.Align.CENTER); drawBitmapContain(c,ref1,W/2,s(935),170,170); button(c,"BACK",1120);
    }

    private final Runnable frame = new Runnable(){@Override public void run(){
        if(!loopRunning)return;
        long now=System.nanoTime(); float dt=last==0?0:Math.min(.033f,(now-last)/1e9f); last=now;
        if(screen==Screen.PLAY) update(dt);
        invalidate();
        handler.postDelayed(this,16);
    }};

    private void startLoop(){
        loopRunning=true; last=System.nanoTime(); handler.removeCallbacks(frame); handler.post(frame);
    }
    private void stopLoop(){loopRunning=false;handler.removeCallbacks(frame);}

    void startGame(){
        screen=Screen.PLAY; score=0; falls.clear(); pops.clear(); shake=0; spawnClock=0; playerX=W/2f; targetX=playerX; startLoop();
    }
    void showMenu(){stopLoop();screen=Screen.MENU;invalidate();}
    void showHowTo(){stopLoop();screen=Screen.HOWTO;invalidate();}
    void gameOver(){stopLoop();screen=Screen.GAMEOVER;invalidate();}

    void play(Canvas c){
        c.save(); if(shake>0){float a=s(shake*7);c.translate((rng.nextFloat()*2-1)*a,(rng.nextFloat()*2-1)*a);}
        round(c,s(25),s(25),W-s(25),s(125),28,0xCC0B1A31); text(c,"SCORE  "+score,s(55),s(88),32,Color.WHITE,Paint.Align.LEFT); text(c,"BEST  "+best,W/2,s(88),26,0xFF9DC8DD,Paint.Align.CENTER);
        round(c,W-s(150),s(40),W-s(40),s(110),20,0xFF163A59); text(c,"Ⅱ",W-s(95),s(86),31,Color.WHITE,Paint.Align.CENTER);
        for(Fall f:falls)drawFall(c,f); drawBitmapContain(c,head,playerX,H-s(220),390,330);
        for(Pop q:pops){p.setAlpha((int)(255*Math.max(0,q.life)));text(c,q.text,q.x,q.y,30,Color.WHITE,Paint.Align.CENTER);p.setAlpha(255);} c.restore();
        if(screen==Screen.PAUSE){round(c,s(150),s(650),W-s(150),s(1100),40,0xDD0B1A31);text(c,"PAUSED",W/2,s(800),55,Color.WHITE,Paint.Align.CENTER);text(c,"TAP TO RESUME",W/2,s(900),30,0xFF5DE3FF,Paint.Align.CENTER);}
    }

    void update(float dt){
        float diff=1f+Math.min(1.9f,score/25f); playerX+=(targetX-playerX)*Math.min(1,dt*14); spawnClock-=dt*1000; float interval=Math.max(330,760-score*7);
        if(spawnClock<=0){boolean bomb=rng.nextFloat()<Math.min(.24f,.035f+score*.0038f);float r=s(27+rng.nextInt(13));float x=s(70)+rng.nextFloat()*(W-s(140));falls.add(new Fall(x,-r,r,s(330+Math.min(score,200)*5)*diff,bomb));spawnClock=interval;}
        Iterator<Fall> it=falls.iterator();float headY=H-s(220),hitRadius=s(105);
        while(it.hasNext()){
            Fall f=it.next();f.y+=f.vy*dt;f.x+=Math.sin(f.y*.008)*s(f.drift*10)*dt;
            if(Math.hypot(f.x-playerX,f.y-headY)<f.r+hitRadius){
                if(f.bomb){if(score>best){best=score;saveBest();}shake=.9f;if(hitS!=null){try{hitS.start();}catch(Exception ignored){}}it.remove();gameOver();return;}
                score++;if(score>best){best=score;saveBest();}pops.add(new Pop(f.x,f.y-20,"+1"));if(popS!=null){try{popS.start();}catch(Exception ignored){}}it.remove();
            } else if(f.y>H+s(100))it.remove();
        }
        for(Iterator<Pop> pi=pops.iterator();pi.hasNext();){Pop q=pi.next();q.y-=s(55)*dt;q.life-=dt;if(q.life<=0)pi.remove();} shake=Math.max(0,shake-dt*2.2f);
    }
    void saveBest(){getContext().getSharedPreferences("save",0).edit().putInt("best",best).apply();}
    void drawFall(Canvas c,Fall f){if(f.bomb){p.setColor(0xFF17191D);c.drawCircle(f.x,f.y,f.r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(s(5));p.setColor(0xFF5B626B);c.drawCircle(f.x,f.y,f.r,p);p.setStyle(Paint.Style.FILL);p.setColor(0xFFFFB22E);c.drawCircle(f.x+f.r*.7f,f.y-f.r*.9f,f.r*.22f,p);text(c,"!",f.x,f.y+s(13),35,Color.WHITE,Paint.Align.CENTER);}else{int[] cols={0xFF40D9FF,0xFFFF65B5,0xFFFFD15C,0xFF7CFF7A,0xFFB77CFF};p.setColor(cols[(int)(Math.abs(f.x)+f.r)%cols.length]);c.drawCircle(f.x,f.y,f.r,p);p.setColor(0x55FFFFFF);c.drawCircle(f.x-f.r*.3f,f.y-f.r*.3f,f.r*.25f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(s(3));p.setColor(0xAAFFFFFF);c.drawCircle(f.x,f.y,f.r,p);p.setStyle(Paint.Style.FILL);}}
    void result(Canvas c){text(c,"AYYOOO! ENTE THALA POYI! 😂",W/2,s(180),38,0xFFFF7474,Paint.Align.CENTER);text(c,"GAME OVER",W/2,s(255),52,Color.WHITE,Paint.Align.CENTER);text(c,"FINAL SCORE: "+score,W/2,s(325),32,0xFFD4EAF5,Paint.Align.CENTER);drawBitmapContain(c,lose,W/2,s(555),510,470);text(c,"BETTER LUCK NEXT TIME!",W/2,s(900),34,0xFFFFD15C,Paint.Align.CENTER);drawBitmapContain(c,retry,W/2,s(1160),380,420);button(c,"PLAY AGAIN",1370);button(c,"MAIN MENU",1505);}

    boolean hit(float rawX,float rawY,float l,float t,float r,float b){float x=logicalX(rawX),y=logicalY(rawY);return x>=l&&x<=r&&y>=t&&y<=b;}
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getActionMasked()!=MotionEvent.ACTION_DOWN && e.getActionMasked()!=MotionEvent.ACTION_MOVE && e.getActionMasked()!=MotionEvent.ACTION_UP)return true;
        float x=e.getX(), y=e.getY();
        if(screen==Screen.MENU && e.getActionMasked()==MotionEvent.ACTION_DOWN){
            if(hit(x,y,80,735,1000,885)){startGame();performClick();return true;}
            if(hit(x,y,80,870,1000,1020)){showHowTo();performClick();return true;}
            return true;
        }
        if(screen==Screen.HOWTO && e.getActionMasked()==MotionEvent.ACTION_DOWN){if(hit(x,y,80,1090,1000,1260)){showMenu();performClick();}return true;}
        if(screen==Screen.GAMEOVER && e.getActionMasked()==MotionEvent.ACTION_DOWN){
            if(hit(x,y,80,1340,1000,1500)){startGame();performClick();return true;}
            if(hit(x,y,80,1480,1000,1645)){showMenu();performClick();return true;}
            return true;
        }
        if(screen==Screen.PAUSE && e.getActionMasked()==MotionEvent.ACTION_DOWN){screen=Screen.PLAY;startLoop();performClick();return true;}
        if(screen==Screen.PLAY){
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN && hit(x,y,900,20,1060,150)){screen=Screen.PAUSE;stopLoop();invalidate();performClick();return true;}
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN||e.getActionMasked()==MotionEvent.ACTION_MOVE||e.getActionMasked()==MotionEvent.ACTION_UP){targetX=Math.max(s(90),Math.min(W-s(90),x));return true;}
        }
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();}
    @Override protected void onDetachedFromWindow(){stopLoop();if(popS!=null)popS.release();if(hitS!=null)hitS.release();super.onDetachedFromWindow();}
}
