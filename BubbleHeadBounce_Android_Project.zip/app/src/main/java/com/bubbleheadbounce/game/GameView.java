package com.bubbleheadbounce.game;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.MediaPlayer;
import android.view.*;
import java.util.*;

public class GameView extends View {
    enum Screen { MENU, HOWTO, PLAY, PAUSE, GAMEOVER, WIN }
    Screen screen=Screen.MENU;
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    Random rng=new Random();
    Bitmap head,win,lose,retry,ref1,ref2;
    ArrayList<Fall> falls=new ArrayList<>();
    ArrayList<Pop> pops=new ArrayList<>();
    float playerX, targetX, shake=0;
    int score=0,best=0;
    long last=0, spawnClock=0;
    float W,H,scale;
    boolean dragging=false;
    MediaPlayer popS,hitS,winS;

    class Fall {
        float x,y,r,vy,drift; boolean bomb;
        Fall(float x,float y,float r,float vy,boolean b){this.x=x;this.y=y;this.r=r;this.vy=vy;this.bomb=b;drift=(rng.nextFloat()*2-1)*.55f;}
    }
    class Pop {float x,y,life; String text; Pop(float x,float y,String t){this.x=x;this.y=y;text=t;life=1;}}
    public GameView(Context c){
        super(c);
        setFocusable(true);
        setClickable(true);
        head=load(com.bubbleheadbounce.game.R.drawable.head);
        win=load(R.drawable.win); lose=load(R.drawable.lose); retry=load(R.drawable.retry);
        ref1=load(R.drawable.ui_ref1); ref2=load(R.drawable.ui_ref2);
        try { popS=MediaPlayer.create(c,R.raw.pop); hitS=MediaPlayer.create(c,R.raw.hit); winS=MediaPlayer.create(c,R.raw.win); } catch(Exception e){}
        best=c.getSharedPreferences("save",0).getInt("best",0);
    }
    Bitmap load(int id){return BitmapFactory.decodeResource(getResources(),id);}

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){W=w;H=h;scale=Math.min(W/1080f,H/1920f); if(playerX==0)playerX=W/2f; targetX=playerX;}
    float s(float v){return v*scale;}
    void bg(Canvas c){
        c.drawColor(Color.rgb(7,17,31));
        p.setShader(new LinearGradient(0,0,0,H,Color.rgb(10,32,60),Color.rgb(35,8,58),Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p); p.setShader(null);
        p.setColor(0x1835D6FF);
        for(int i=0;i<12;i++){float x=(i*137)%W,y=(i*263+80)%H;c.drawCircle(x,y,s(4+(i%3)*3),p);}
    }
    void text(Canvas c,String t,float x,float y,float size,int color,Paint.Align align){
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(s(size));p.setColor(color);p.setTextAlign(align);p.setStyle(Paint.Style.FILL);c.drawText(t,x,y,p);
    }
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){
        p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,s(rad),s(rad),p);
    }
    void button(Canvas c,String label,float y){
        float l=s(160),r=W-s(160),t=s(y),b=s(y+110);
        round(c,l,t,r,b,28,0xFF21B6E8);
        round(c,l+s(5),t+s(5),r-s(5),b-s(5),24,0xFF123C6B);
        text(c,label,W/2,t+s(72),38,Color.WHITE,Paint.Align.CENTER);
    }
    void drawBitmapContain(Canvas c,Bitmap b,float cx,float cy,float maxW,float maxH){
        if(b==null)return;
        float k=Math.min(s(maxW)/b.getWidth(),s(maxH)/b.getHeight());
        float bw=b.getWidth()*k,bh=b.getHeight()*k;
        c.drawBitmap(b,null,new RectF(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2),p);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); bg(c);
        if(screen==Screen.MENU) menu(c);
        else if(screen==Screen.HOWTO) howto(c);
        else if(screen==Screen.PLAY||screen==Screen.PAUSE) play(c);
        else if(screen==Screen.GAMEOVER) result(c,false);
        else result(c,true);
        if(screen==Screen.PLAY) { postInvalidateOnAnimation(); }
    }

    void menu(Canvas c){
        text(c,"BUBBLE",W/2,s(165),78,Color.WHITE,Paint.Align.CENTER);
        text(c,"HEAD BOUNCE",W/2,s(245),62,0xFF5DE3FF,Paint.Align.CENTER);
        // UI reference art as decorative menu characters
        drawBitmapContain(c,ref1,s(165),s(470),240,330);
        drawBitmapContain(c,ref2,W-s(165),s(470),220,330);
        drawBitmapContain(c,head,W/2,s(490),350,350);
        button(c,"PLAY",760); button(c,"HOW TO PLAY",895); button(c,"BEST SCORE  "+best,1030);
        text(c,"Catch the bubbles • Dodge the bombs",W/2,s(1175),25,0xFFD9EEFF,Paint.Align.CENTER);
        text(c,"Offline arcade • 60 FPS style",W/2,s(1215),21,0xFF8FB0C9,Paint.Align.CENTER);
    }
    void howto(Canvas c){
        text(c,"HOW TO PLAY",W/2,s(160),58,Color.WHITE,Paint.Align.CENTER);
        round(c,s(80),s(245),W-s(80),s(1040),36,0xCC102744);
        text(c,"🫧 CATCH THE BALLS",W/2,s(345),34,0xFF62E8FF,Paint.Align.CENTER);
        text(c,"Move your head left & right",W/2,s(410),28,Color.WHITE,Paint.Align.CENTER);
        text(c,"to collect falling bubbles.",W/2,s(455),28,Color.WHITE,Paint.Align.CENTER);
        text(c,"💣 AVOID THE BOMBS",W/2,s(555),34,0xFFFF7676,Paint.Align.CENTER);
        text(c,"A bomb touching your head",W/2,s(620),28,Color.WHITE,Paint.Align.CENTER);
        text(c,"ends the run immediately.",W/2,s(665),28,Color.WHITE,Paint.Align.CENTER);
        text(c,"🏆 REACH 50 POINTS",W/2,s(765),34,0xFFFFD15C,Paint.Align.CENTER);
        text(c,"Win the game at the target score.",W/2,s(830),28,Color.WHITE,Paint.Align.CENTER);
        drawBitmapContain(c,ref1,W/2,s(935),170,170);
        button(c,"BACK",1120);
    }

    void startGame(){
        screen=Screen.PLAY;
        score=0;
        falls.clear();
        pops.clear();
        shake=0;
        spawnClock=0;
        playerX=W/2f;
        targetX=playerX;
        last=System.nanoTime();
        // Force the first PLAY frame immediately; do not wait for another Android redraw.
        post(new Runnable(){ public void run(){ invalidate(); }});
    }
    void play(Canvas c){
        long now=System.nanoTime(); float dt=Math.min(.033f,(now-last)/1e9f); last=now;
        if(screen==Screen.PLAY) update(dt);
        c.save();
        if(shake>0){float a=s(shake*7);c.translate((rng.nextFloat()*2-1)*a,(rng.nextFloat()*2-1)*a);}
        // HUD
        round(c,s(25),s(25),W-s(25),s(125),28,0xCC0B1A31);
        text(c,"SCORE  "+score,s(55),s(88),32,Color.WHITE,Paint.Align.LEFT);
        text(c,"BEST  "+best,W/2,s(88),26,0xFF9DC8DD,Paint.Align.CENTER);
        round(c,W-s(150),s(40),W-s(40),s(110),20,0xFF163A59);
        text(c,"Ⅱ",W-s(95),s(86),31,Color.WHITE,Paint.Align.CENTER);

        // target bar
        round(c,s(45),s(145),W-s(45),s(165),10,0x552F6A82);
        round(c,s(45),s(145),s(45)+(W-s(90))*Math.min(1,score/50f),s(165),10,0xFF43D6FF);
        text(c,"TARGET 50",W-s(55),s(205),20,0xFFA8D9E8,Paint.Align.RIGHT);

        for(Fall f:falls) drawFall(c,f);
        // player head at bottom
        float px=playerX, py=H-s(220);
        drawBitmapContain(c,head,px,py,390,330);
        for(Pop q:pops){float a=Math.max(0,q.life);p.setAlpha((int)(255*a));text(c,q.text,q.x,q.y,30,Color.WHITE,Paint.Align.CENTER);p.setAlpha(255);}
        c.restore();
        if(screen==Screen.PLAY) postInvalidateDelayed(8);
    }
    void update(float dt){
        float diff=1f+Math.min(1.9f,score/25f);
        playerX += (targetX-playerX)*Math.min(1,dt*14);
        spawnClock-=dt*1000;
        float interval=Math.max(330,760-score*7);
        if(spawnClock<=0){
            boolean bomb=rng.nextFloat() < Math.min(.24f,.035f+score*.0038f);
            float r=s(27+rng.nextInt(13));
            float x=s(70)+rng.nextFloat()*(W-s(140));
            falls.add(new Fall(x,-r,r,s(330+score*5)*diff,bomb));
            spawnClock=interval;
        }
        Iterator<Fall> it=falls.iterator();
        float headY=H-s(220), hitRadius=s(105);
        while(it.hasNext()){
            Fall f=it.next(); f.y+=f.vy*dt; f.x+=Math.sin(f.y*.008)*s(f.drift*10)*dt;
            if(Math.hypot(f.x-playerX,f.y-headY)<f.r+hitRadius){
                if(f.bomb){ screen=Screen.GAMEOVER; if(score>best){best=score;getContext().getSharedPreferences("save",0).edit().putInt("best",best).apply();} shake=.9f; if(hitS!=null)hitS.start(); it.remove(); return; }
                score++; if(score>best){best=score;getContext().getSharedPreferences("save",0).edit().putInt("best",best).apply();}
                pops.add(new Pop(f.x,f.y-20,"+1")); if(popS!=null)popS.start(); it.remove();
                if(score>=50){screen=Screen.WIN;if(winS!=null)winS.start();return;}
            } else if(f.y>H+s(100)) it.remove();
        }
        for(Iterator<Pop> pi=pops.iterator();pi.hasNext();){Pop q=pi.next();q.y-=s(55)*dt;q.life-=dt;if(q.life<=0)pi.remove();}
        shake=Math.max(0,shake-dt*2.2f);
    }
    void drawFall(Canvas c,Fall f){
        if(f.bomb){
            p.setColor(0xFF17191D);c.drawCircle(f.x,f.y,f.r,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(s(5));p.setColor(0xFF5B626B);c.drawCircle(f.x,f.y,f.r,p);p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFB22E);c.drawCircle(f.x+f.r*.7f,f.y-f.r*.9f,f.r*.22f,p);
            p.setColor(0xFFFFE46A);c.drawCircle(f.x+f.r*.7f,f.y-f.r*1.05f,f.r*.10f,p);
            text(c,"!",f.x,f.y+s(13),35,Color.WHITE,Paint.Align.CENTER);
        }else{
            int[] cols={0xFF40D9FF,0xFFFF65B5,0xFFFFD15C,0xFF7CFF7A,0xFFB77CFF};
            p.setColor(cols[(int)(Math.abs(f.x)+f.r)%cols.length]);c.drawCircle(f.x,f.y,f.r,p);
            p.setColor(0x55FFFFFF);c.drawCircle(f.x-f.r*.3f,f.y-f.r*.3f,f.r*.25f,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(s(3));p.setColor(0xAAFFFFFF);c.drawCircle(f.x,f.y,f.r,p);p.setStyle(Paint.Style.FILL);
        }
    }
    void result(Canvas c,boolean won){
        text(c,won?"GAME WON! 🎉":"AYYOOO! ENTE THALA POYI! 😂",W/2,s(180),won?55:38,won?0xFFFFD15C:0xFFFF7474,Paint.Align.CENTER);
        if(!won){text(c,"GAME OVER",W/2,s(255),52,Color.WHITE,Paint.Align.CENTER);}
        text(c,"FINAL SCORE: "+score,W/2,s(325),32,0xFFD4EAF5,Paint.Align.CENTER);
        if(won){
            drawBitmapContain(c,win,W/2,s(680),560,650);
            // confetti
            for(int i=0;i<32;i++){float x=s(80+(i*83)%920),y=s(390+(i*97)%600);p.setColor(new int[]{0xFFFFD15C,0xFF4BE8FF,0xFFFF5D9B,0xFF79FF73}[i%4]);c.drawCircle(x,y,s(6+(i%3)*2),p);}
            text(c,"50 BUBBLES CAUGHT!",W/2,s(1070),27,0xFF8DEAFF,Paint.Align.CENTER);
        } else {
            drawBitmapContain(c,lose,W/2,s(555),510,470);
            text(c,"BETTER LUCK NEXT TIME!",W/2,s(900),34,0xFFFFD15C,Paint.Align.CENTER);
            drawBitmapContain(c,retry,W/2,s(1160),380,420);
        }
        button(c,"PLAY AGAIN",1370);
        button(c,"MAIN MENU",1505);
    }

    private boolean insideButton(float rawY, float logicalTop, float logicalBottom){
        float ly = rawY / scale;
        return ly >= logicalTop && ly <= logicalBottom;
    }

    @Override public boolean performClick(){
        super.performClick();
        return true;
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        final float x=e.getX();
        final float y=e.getY();
        final int action=e.getActionMasked();

        if(action==MotionEvent.ACTION_DOWN){
            if(screen==Screen.MENU){
                if(insideButton(y,760,870)){
                    performClick();
                    startGame();
                    return true;
                }
                if(insideButton(y,895,1005)){
                    performClick();
                    screen=Screen.HOWTO;
                    postInvalidateOnAnimation();
                    return true;
                }
            }
            else if(screen==Screen.HOWTO){
                if(insideButton(y,1120,1230)){
                    performClick();
                    screen=Screen.MENU;
                    postInvalidateOnAnimation();
                    return true;
                }
            }
            else if(screen==Screen.PLAY){
                if(insideButton(y,25,125) && x >= W-s(150) && x <= W-s(40)){
                    performClick();
                    screen=Screen.PAUSE;
                    postInvalidateOnAnimation();
                    return true;
                }
                targetX=Math.max(s(90),Math.min(W-s(90),x));
                dragging=true;
                return true;
            }
            else if(screen==Screen.PAUSE){
                performClick();
                screen=Screen.PLAY;
                last=System.nanoTime();
                postInvalidateOnAnimation();
                return true;
            }
            else if(screen==Screen.GAMEOVER || screen==Screen.WIN){
                if(insideButton(y,1370,1480)){
                    performClick();
                    startGame();
                    return true;
                }
                if(insideButton(y,1505,1615)){
                    performClick();
                    screen=Screen.MENU;
                    postInvalidateOnAnimation();
                    return true;
                }
            }
            return true;
        }

        if((action==MotionEvent.ACTION_MOVE || action==MotionEvent.ACTION_UP) && screen==Screen.PLAY){
            targetX=Math.max(s(90),Math.min(W-s(90),x));
            dragging=action!=MotionEvent.ACTION_UP;
            return true;
        }
        return true;
    }
}
